﻿using Microsoft.AspNetCore.Mvc;
using PayPal.Api;
using PaypalDemo.Models;
using PaypalDemo.Services;

namespace PaypalDemo.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PayPalController : ControllerBase
    {
        private readonly PayPalService _payPalService;

        public PayPalController(PayPalService payPalService)
        {
            _payPalService = payPalService;
        }

        [HttpPost("create-payment")]
        public async Task<IActionResult> CreatePayment(decimal amount)
        {
            var returnUrl = "https://localhost:7226/api/paypal/success";
            var cancelUrl = "https://localhost:7226/api/paypal/cancel";
            var paymentResponse = await _payPalService.CreatePaymentAsync(amount, returnUrl, cancelUrl);

            return Ok(paymentResponse);
        }

        [HttpGet("success")]
        public async Task<IActionResult> PaymentSuccess(string paymentId, string token, string payerID)
        {
            var paymentDetails = await _payPalService.ExecutePaymentAsync(paymentId, payerID);
            var amount = paymentDetails.transactions[0].amount.total;
            using (var context = new TransactionDbContext())
            {
                context.TransactionPayPals.Add(new TransactionPayPal() { PaymentId = paymentId, PayerId = payerID, Amount = amount });
                context.SaveChanges();
            }
                return Ok("Payment successful!");
        }

        [HttpGet("cancel")]
        public IActionResult PaymentCancel()
        {
            return Ok("Payment cancelled.");
        }
        [HttpGet("transactions")]
        public async Task<List<TransactionPayPal>> GetAllTransactions()
        {
            using (var context = new TransactionDbContext())
            {
                return context.TransactionPayPals.ToList();
            }
        }
    }
}
